package com.example.kechennsheji;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EdgeEffect;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.kechennsheji.User.SettingActivity;
import com.example.kechennsheji.User.UserActivity;

import java.util.*;

public class MainActivity extends AppCompatActivity {
private EditText editText2;
private Button chakan;
private Button fenxibaogao;
private Button user;
private Button mBtnManagerSort;
private String m_sort;
private TextView textView3;
private RadioButton Rd_payin,Rd_payout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        chakan=findViewById(R.id.btn_chakanzhangdan);
        user=findViewById(R.id.btn_yonghuzhongxin);
        fenxibaogao=findViewById(R.id.btn_fenxibaogao);
        mBtnManagerSort=findViewById(R.id.manager_sort);
        Rd_payin=findViewById(R.id.RB_payin);
        Rd_payout=findViewById(R.id.RB_payout);
        setclicklinster();
     /*   Rd_payin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            }
        });
*/


        textView3=findViewById(R.id.et_3);
        m_sort=getIntent().getStringExtra("name");
        textView3.setText(m_sort);
        //调出日历
        editText2=findViewById(R.id.et_22);
        editText2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    showDatePickDlg();
                    return true;
                }
                return false;
            }
        });
        editText2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    showDatePickDlg();
                }
            }
        });
    }



    public void setclicklinster()
    {
        onClick onclick=new onClick();
        chakan.setOnClickListener(onclick);
        fenxibaogao.setOnClickListener(onclick);
        user.setOnClickListener(onclick);
       /* Rd_payin.setOnClickListener(onclick);
        Rd_payout.setOnClickListener(onclick);*/
        mBtnManagerSort.setOnClickListener(onclick);

    }



    private class onClick implements View.OnClickListener{
        public void onClick(View view)
        {
            Intent intent=null;
            switch (view.getId())
            {
                case R.id.btn_chakanzhangdan:
                    intent=new Intent(MainActivity.this,BillListActivity.class);
                    break;
                case R.id.btn_fenxibaogao:
                    intent=new Intent(MainActivity.this,AnalysisChartActivity.class);
                    break;
                case R.id.btn_yonghuzhongxin:
                    intent=new Intent(MainActivity.this,UserActivity.class);
                    break;
                case R.id.manager_sort:
                    intent=new Intent(MainActivity.this,ManagersortActivity.class);
                    break;
            }
            startActivity(intent);

        }

    }

    protected void showDatePickDlg() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                MainActivity.this.editText2.setText(year + "-" + monthOfYear + "-" + dayOfMonth);
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();


    }
}
